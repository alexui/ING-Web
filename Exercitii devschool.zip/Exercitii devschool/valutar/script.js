var appValutar = angular.module("appValutar", []);

appValutar.controller(
	"valutarCtrl",
	function ($scope) {

		$scope.currencies = [
			{
				label: "EUR",
				value: 0.22
			},
			{
				label: "USD",
				value: 0.24
			},
			{
				label: "GBP",
				value: 0.16
			},
			{
				label: "YEN",
				value: 29.79
			}
		];
		$scope.sumaRON = 0;
		$scope.currencyValue = 0.22;
	}
)
