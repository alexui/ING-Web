var myApp = angular.module("myApp", ["ngRoute"]);

myApp.config(function($routeProvider){
	$routeProvider
	.when(
		"/about",
		{
			template:`
				<h1> This is hte about page </h1>
			`
		}
	)
	.when(
		"/list",
		{
			template: `
				<div ng-repeat="user in users">
					<user data="{{user}}"></user>	
				</div>
			`,
			controller: mainCtrl
		}
	)
	.when(
		"/add/:id",
		{
			template: "this is the add page",
			controller: addCtrl
		}
	);

	$routeProvider.otherwise({redirectTo: '/about'});
});

var addCtrl = function($scope, $routeParams) {
	alert("Voi edita obiectul cu id" + $routeParams.id);
};

var mainCtrl = function($scope, appService){
		$scope.users = [];

		var getDataFromServer = function(){
			appService.getData().then(
				function(data) { //success
					alert("au sosit datele");
					$scope.users = data.data;
					console.log(data);
				},
				function error(err) { // error
					alert("ceva s-a intamplat gresit!");
					console.log(err);
				}
				);
		}

		getDataFromServer();

		$scope.$on(
			"dateSterse",
			function(){
				alert("trebuie sa fac refresh");
				getDataFromServer();
			}
			);

		$scope.dataTest = "ana are mere";
};

myApp.service(
	"appService",
	function($http) {
		var service = {};
		
		service.getData = function() {
			return $http({
				method: "GET",
				url: "http://jsonplaceholder.typicode.com/users"
			})
		}

		service.deleteUser = function(id) {
			return $http({
				method: "DELETE",
				url: "http://jsonplaceholder.typicode.com/users/" + id
			})
		}

		return service;
	}
	);

myApp.directive(
	"user",
	function(appService) {
		return {
			restrict: "E",
			scope: {data: "@"},
			link: function(scope, el){
				scope.user = angular.fromJson(scope.data);
				scope.doDelete = function() {
					appService.deleteUser(scope.user.id).then(
						function(data){
							scope.$emit("dateSterse");
						},
						function(err){

						}
						);
				}
			},
			template: `
			<div class="user-card">
				<h4>{{user.name}}</h4>
				<h4>email: {{user.email}}</h4>
				<h4>web: {{user.website}}</h4>
				<span ng-click="doDelete()" class="delete-link">x</span>
				<a ng-href="#/add/{{user.id}}" class="edit-link">e</a>
			</div>
			`
		}
	}
	);