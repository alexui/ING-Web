var orderApp = angular.module("orderApp", []);

orderApp.controller(
	"OrderFormController",
	function($scope) {
		$scope.totalSum = 0;
		$scope.products = [
			{
				name: 'Tutorials Development',
				price: 500,
				active:false
			},{
				name: 'Tutorials Design',
				price: 300,
				active:false
			},{
				name: 'Code Integration',
				price: 250,
				active:false
			},{
				name: 'Training',
				price: 220,
				active:false
			}
		];
	}
)
